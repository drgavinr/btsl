#!/usr/bin/env python3
#takes wiki xml files. Splits and merges them into xml files with different numbers of pages. Can merge small files into bigger files or split bigger files into smaller files.
#all files in input directory will be included
#result will be saved to output directory

#SET UP PARAMETERS

batchname = 'example'#base name for XML files. Can be anything. Filename will be automatically prefixed with 'aaa-' to make it easier to find.

maxpages = 5000#maximum number of pages per XML file.

inpath = 'merge in'#input directory. Can usually be left as is.

outpath = 'merge out'#output directory. Can usually be left as is.

#NO NEED TO EDIT AFTER HERE
#import libraries
import os
from wikifunctions import *

#set up empty list for pages
pagestext = []
#get list of xml files in input directory
infilenames = sorted(os.listdir(inpath))
#loop through list and open each file
for infilename in infilenames:
    #read into string
    infile = open(inpath + '/' + infilename)
    instring = infile.read()
    #strip </mediawiki> from end -13
    #split on </siteinfo> and use [1]
    #split on <page>
    inpages = instring[:-13].split('</siteinfo>')[1].split('<page>')[1:]
    #loop through, add '<page>' back, and append to pagestext[]
    for inpage in inpages:
        pagestext.append('<page>' + inpage)


#call merge function
mergepages(pagestext, outpath, batchname, maxpages)
