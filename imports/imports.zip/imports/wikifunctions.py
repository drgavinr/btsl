#!/usr/bin/env python3
#functions for generating wiki pages from CSV

#import libraries
import datetime
import os

def tsvtorows(infilepath):
    #opens a TSV file and returns contents as a list of all rows
    #file should usually use tabs as separators and must not put quotes around text (only exception is master list of nested templates, which uses ;). This doesn't affect this function but will cause problems further down the line if wrong.
    #returns empty list if file doesn't exist
    
    #check that file exists
    if os.path.isfile(infilepath):
        #if file exists: open, read, split and close file
        infile = open(infilepath)
        tsvrows = infile.read().splitlines()
        infile.close()
        return tsvrows
    else:
        return []
    
def get_template_params(row):
    #takes a string (which should ususally be derived from the first row of a TSV file) and returns a list which contains template parameter names
    #first column omitted as assumed to always be for page names
    return row.split('\t')[1:]
    
def pagedict(tsvrows):
    #takes a list of rows of main TSV, returns a dictionary with a key for each page name and empty string as value
    
    #create empty dictionary
    pagedict = {}
    #loop through rows, skipping headings in row 0
    for tsvrow in tsvrows[1:]:
        #add this pagename to dictionary
        pagename = tsvrow.split('\t')[0]
        pagedict[pagename] = ''
    return pagedict

def tldict(pagedict, tlname, inpath, sep=''):
    #takes:
    #dictionary containing pagenames and empty strings
    #template name (this should correspond to a tsv file)
    #file path
    #separator (defaults to empty string) to be put after each template instance
    #returns: dictionary with template text for each page

    #get TSV from file
    subrows = tsvtorows(inpath + tlname + '.csv')
    #make sure there was some data in the file
    if len(subrows) > 1:
        #get paramater names from 1st row
        pnames = get_template_params(subrows[0])
        #loop through 1:
        for subrow in subrows[1:]:
            #split row
            pvalues = subrow.split('\t')
            #get pagename
            pagename = pvalues[0]
            #open template instance
            pagedict[pagename] += '{{' + tlname
            #combine parameter names and values
            tlrows = zip(pnames, pvalues[1:])
            #loop through parameters
            for tlrow in tlrows:
                #only write parameter name to file if actually has a value otherwise default values in templates won't work
                if tlrow[1] != '':
                    pagedict[pagename] += '\n|' + tlrow[0] + '=' + tlrow[1]
            #close template instance
            pagedict[pagename] += '}}' + sep

    #return dictionary
    return pagedict

def get_nested_subtls(inpath, mainrows):
    #returns a list of lists with parent parameter, nested subtemplate name and dictionary of values
    
    #set up empty list which will have values appended to it
    returnlist = []
    #get paramers and template names from CSV file
    firstlevels = tsvtorows('settings/subtemplates nested.txt')
    
    for firstlevel in firstlevels[1:]:
        secondlevels = firstlevel.split(';')
        
        returnlist.append([secondlevels[0], secondlevels[1], tldict(pagedict(mainrows), secondlevels[1], inpath)])
        
    return returnlist

def wikitimestamp():
    #generate timestamp and return as string
    return '<timestamp>' + datetime.datetime.now().isoformat().rstrip('0123456789').rstrip('.') + 'Z</timestamp>'

def wikistartxml():
    #return string with start of xml file. This is specific to each wiki but doesn't always have to match the target wiki, as XML exported from one wiki will usually work in another.
    return '<mediawiki xmlns="http://www.mediawiki.org/xml/export-0.10/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.mediawiki.org/xml/export-0.10/ http://www.mediawiki.org/xml/export-0.10.xsd" version="0.10" xml:lang="en-GB">\n<siteinfo>\n<sitename>By The Sword Linked</sitename>\n<dbname>bytheswo_lbcwdb</dbname>\n<base>https://www.bytheswordlinked.uk/wiki/Main_Page</base>\n<generator>MediaWiki 1.31.1</generator>\n<case>first-letter</case>\n<namespaces>\n<namespace key="-2" case="first-letter">Media</namespace>\n<namespace key="-1" case="first-letter">Special</namespace>\n<namespace key="0" case="first-letter" />\n<namespace key="1" case="first-letter">Talk</namespace>\n<namespace key="2" case="first-letter">User</namespace>\n<namespace key="3" case="first-letter">User talk</namespace>\n<namespace key="4" case="first-letter">Project</namespace>\n<namespace key="5" case="first-letter">Project talk</namespace>\n<namespace key="6" case="first-letter">File</namespace>\n<namespace key="7" case="first-letter">File talk</namespace>\n<namespace key="8" case="first-letter">MediaWiki</namespace>\n<namespace key="9" case="first-letter">MediaWiki talk</namespace>\n<namespace key="10" case="first-letter">Template</namespace>\n<namespace key="11" case="first-letter">Template talk</namespace>\n<namespace key="12" case="first-letter">Help</namespace>\n<namespace key="13" case="first-letter">Help talk</namespace>\n<namespace key="14" case="first-letter">Category</namespace>\n<namespace key="15" case="first-letter">Category talk</namespace>\n<namespace key="102" case="first-letter">Property</namespace>\n<namespace key="103" case="first-letter">Property talk</namespace>\n<namespace key="106" case="first-letter">Form</namespace>\n<namespace key="107" case="first-letter">Form talk</namespace>\n<namespace key="108" case="first-letter">Concept</namespace>\n<namespace key="109" case="first-letter">Concept talk</namespace>\n<namespace key="112" case="first-letter">smw/schema</namespace>\n<namespace key="113" case="first-letter">smw/schema talk</namespace>\n<namespace key="114" case="first-letter">Rule</namespace>\n<namespace key="115" case="first-letter">Rule talk</namespace>\n<namespace key="420" case="first-letter">GeoJson</namespace>\n<namespace key="421" case="first-letter">GeoJson talk</namespace>\n<namespace key="3000" case="first-letter">Locations</namespace>\n<namespace key="3001" case="first-letter">Locations talk</namespace>\n<namespace key="3002" case="first-letter">Events</namespace>\n<namespace key="3003" case="first-letter">Events talk</namespace>\n</namespaces>\n</siteinfo>'


def wikistartpage(pagename, userid='1', username='Gavin', nsnumber='0', commentstr='Automatically generated'):
    #return string with XML tags to open a page
    
    #open page tag
    pagestr = '<page>\n<title>' + pagename + '</title>\n<ns>' + nsnumber +'</ns>\n<revision>\n'
    #get date and time
    pagestr += wikitimestamp()
    #add rest of string
    pagestr += '\n<contributor>\n<username>' + username +'</username>\n<id>' + userid + '</id>\n</contributor>\n<comment>' + commentstr +'</comment>\n<text xml:space="preserve">'
    
    return pagestr

def wikiendxml():
    #return string with end of xml file
    return '</mediawiki>'
    
def wikiendpage():
    #return string with only xml tags to close a page
     return '</text>\n<model>wikitext</model>\n<format>text/x-wiki</format>\n</revision>\n</page>\n'

def mergepages(pagestext, outdirpath, batchname, maxpages=100):
    #merges individual page files into XML files to import to wiki
    #batchname can be anything as only used to make XML filenames
    
    #paths to batch
    outpath = outdirpath + '/aaa-' + batchname + '-'
    #create xml dir
    if not os.path.isdir(outdirpath):
        os.mkdir(outdirpath)
    #set up count vars
    batchcount = 1 #number of batches
    pagecount = 0 #number of pages since start of this batch
    totalpages = 0 #total pages done in all batches
    #open first xml file and write start
    outfile = open(outpath + str(batchcount).zfill(2) + '.xml', 'w')
    outfile.write(wikistartxml())
    #loop through list of page text
    for pagetext in pagestext:
        #write a page to xml file
        outfile.write(pagetext)
        #increment count
        pagecount += 1
        totalpages += 1
        #check count
        if pagecount == maxpages:
            #update counts
            batchcount += 1
            pagecount = 0
            #close this batch
            outfile.write(wikiendxml())
            outfile.close()
            #if any more pages left, start new batch
            if totalpages < len(pagestext):
                outfile = open(outpath + str(batchcount).zfill(2) + '.xml', 'w')
                outfile.write(wikistartxml())
                
    #write end of last xml and close file if not already done
    if not outfile.closed:
        outfile.write(wikiendxml())
        outfile.close()
    return True


def getnsnumber (templatename):
    #find number of namespace that this template should use
    
    #defaults to Main namespace if not specified in file
    nsnumber = '0'
    #open text file and make list of rows
    infile = open('settings/namespaces.txt')
    inrows = infile.read().splitlines()[1:]
    infile.close()
    #loop through, split and check:
    for inrow in inrows:
        rowparts = inrow.split(';')
        if rowparts[0] == templatename:
            nsnumber = rowparts[1]
    return nsnumber

def getfreetext (inpath):
    #make dictionary of pagenames with free text to be added to each page
    
    #create empty dictionary
    textdict = {}
    #set up path to text file
    infilepath = inpath + 'free.txt'
    if os.path.isfile(infilepath):
        infile = open(infilepath)
        pages = infile.read().split('<<')
        infile.close()
        #loop through, split into pagename and text, add to dict
        #don't include first element in list as will be empty
        for page in pages[1:]:
            pair = page.split('>>')
            textdict.update( { pair[0] : pair[1]} )
        return textdict
    else:
        return textdict

def emptydir (inpath):
    #delete all existing files in specified directory
    infilenames = os.listdir(inpath)
    for infilename in infilenames:
        os.remove(inpath + '/' + infilename)
    return True

def specialchars (intext):
    #replaces & > < with entity references so they don't interfere with XML
    return intext.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
