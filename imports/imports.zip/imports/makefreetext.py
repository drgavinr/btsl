#!/usr/bin/env python3
#generates 'free.txt' based on page names in 'main.csv'

#SET UP PARAMETERS
templatename = 'Address'#Template name. Should be exactly the same as name of a wiki template and a subdirectory of 'Templates/', including spaces and capitalization

batchname = 'london-church'#name for the batch. Can be anything but must have a matching subdirectory inside the Template directory.

#NO NEED TO EDIT AFTER HERE
#import libraries
import os
from wikifunctions import *

#set up path to batch directory
inpath = os.path.expanduser('~/src/imports/Templates/') + templatename + '/' + batchname + '/'

#open output file
outfile = open(inpath + 'free.txt', 'w')

#open main csv file, split into rows
mainrows = tsvtorows(inpath + 'main.csv')[1:]
#loop through, get pagenames and write to output file
for mainrow in mainrows:
    outfile.write('<<' + mainrow.split('\t')[0] + '>>\n')
    
outfile.close()
