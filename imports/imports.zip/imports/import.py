#!/usr/bin/env python3
#takes csv files corresponding to wiki templates and generates XML files for import

#SET UP PARAMETERS
templatename = 'Unit'#Template name. Should be exactly the same as name of a wiki template and a subdirectory of 'Templates/', including spaces and capitalization
#batch name: should correspond to a subsubdir

batchname = 'ea-cavalry'#name for the batch. Can be anything but must have a matching subdirectory inside the Template directory. Will be used for part of the output file name.

maxpages = 10000#maximum number of pages per XML file. Can be changed further using script 'xml split merge.py'

usernumber = '1'#wiki user number. Edits will be attributed to this user.

username = 'Gavin'#wiki user name. Edits will be attributed to this user.

commentstr = 'Automatically generated'#edit summary. This will be displayed in page history

#NO NEED TO EDIT AFTER HERE
#import libraries
import os
from wikifunctions import *

#set up namespaces
nsnumber = getnsnumber(templatename)

#set up path to batch directory
inpath = os.path.expanduser('Templates/')  + templatename + '/' + batchname + '/'
#set up path to output directory
xmlpath = os.path.expanduser('merge in')

#list of strings for text of each page
pagestext = []

#open main csv file, split into rows
mainrows = tsvtorows(inpath + 'main.csv')

#call function to get nested template data
nested_subtls = get_nested_subtls(inpath, mainrows)

#call function to get free text
freetext = getfreetext(inpath)

#1st row of 'main.csv' is parameter names
pnames = get_template_params(mainrows[0])

#2nd row onwards are values
for mainrow in mainrows[1:]:
    pvalues = mainrow.split('\t')
    pagename = pvalues[0]
    print(pagename)
    #combine paramater names and values
    tlrows = zip(pnames, pvalues[1:])
    #open string for text of this page with template
    pagetext = '{{' + templatename
    for tlrow in tlrows:
        #only write paramater name if actually has a value otherwise default values in templates won't work
        if tlrow[1] != '':
            pagetext += '\n|' + tlrow[0] + '=' + tlrow[1]
    #check for repeatable subtemplates here
    for nested_subtl in nested_subtls:
        #0 is paramater name, 1 template name (not currently used), 2 dict of pagename:text pairs
        if nested_subtl[2][pagename] != '':
            pagetext += '\n|' + nested_subtl[0] + '=' + nested_subtl[2][pagename]
    #close template
    pagetext += '\n}}'
    
    #check for free text to be added
    #check if key exists in dictionary
    if pagename in freetext:
        pagetext += freetext[pagename]

    #add opening and closing xml to this page and append to master list
    pagestext.append( wikistartpage(pagename, usernumber, username, nsnumber, commentstr) + specialchars(pagetext) + wikiendpage() )

#merge page files into xml files for import
mergepages(pagestext, xmlpath, batchname, maxpages)
