#!/usr/bin/env python3
#takes tsv file and generates wiki xml file to import redirects
#tsv files should go in 'imports/redirects/in/'
#tsv files should have column names in first row: RedirFrom, RedirTo, Sort key, Cats (sep by tab)
#script will use ALL files currently in 'imports/redirects/in/'
#results will be saved in  'imports/imports/merge in/'

#SET UP PARAMETERS

batchname = 'bodleian-redirects'#batch name. Can be anything. Only used for naming xml files, not for locating input or output directories.

maxpages = 10000#maximum number of pages per XML file. Can be changed further using script 'xml split merge.py'

usernumber = '1'#wiki user number. Edits will be attributed to this user.

username = 'Gavin'#wiki user number. Edits will be attributed to this user.

#no need to set up namespace as all imported redirects are expected to be in Main

#NO NEED TO EDIT AFTER HERE
#import libs
import os
from wikifunctions import *
#set up paths
inpath = os.path.expanduser('redirects/in')
outpath = os.path.expanduser('merge in')
#list of strings for text of each page
pagestext = []

#get list of tsv files in redirects/in/
infilenames = sorted(os.listdir(inpath))
#loop through list and open each file
for infilename in infilenames:
    #read into list of rows
    inrows = tsvtorows(inpath + '/' + infilename)[1:]
    for inrow in inrows:
        #print inrow
        #split row
        rowparts = inrow.split('\t')
        #get categories and sort key
        catstring = ''
        if len(rowparts[2]) > 0:
            catstring += '\n{{DEFAULTSORT:' + rowparts[2] + '}}'
        if len(rowparts[3]) > 0:
            catstring += '\n[[Category:' + rowparts[3].replace(';', ']]\n[[Category:') + ']]'
        #open xml for wiki page, add redirect code, close xml
        pagestext.append( wikistartpage(rowparts[0], usernumber, username, '0') + '#REDIRECT [[' + rowparts[1] + ']]' + catstring + wikiendpage() )
        

#merge page files into xml files for import
mergepages(pagestext, outpath, batchname, maxpages)
